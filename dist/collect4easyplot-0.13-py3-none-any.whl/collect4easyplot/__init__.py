from collect4easyplot.data_grabber import collect, clear_all

__all__ = ["collect", "clear_all"]
