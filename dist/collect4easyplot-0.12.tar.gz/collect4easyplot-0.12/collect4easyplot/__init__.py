from collect4easyplot.data_grabber import collect

__all__ = ["collect"]
